# 🎯 SafeStepAI — Sistema de Detección de Objetos con Guía por Voz

> Detección de objetos en tiempo real con narración en español, interfaz gráfica y soporte para cámara web, imágenes y videos.

---

## 📖 Descripción del proyecto

**SafeStepAI** es una aplicación de escritorio que usa visión por computadora para detectar objetos en tiempo real y narrarlos en voz alta en español. Su propósito principal es servir como **asistente de guía visual**, informando al usuario la posición y distancia relativa de los objetos que aparecen en cámara — útil para personas con baja visión o como sistema de asistencia en movimiento.

El sistema detecta hasta 80 categorías de objetos (personas, autos, animales, muebles, etc.), estima su posición horizontal (izquierda, frente, derecha) y distancia relativa (muy cerca, cerca, a media distancia, lejos), y genera frases narradas con artículos gramaticales correctos en español.

Cuenta con dos variantes:
- **`deteccion_objetos.py`**: script de línea de comandos modular, orientado a integración con APIs web.
- **`app_gui.py`**: interfaz gráfica completa con controles interactivos, visor de video en vivo y panel de detecciones.

---

## 🧰 Tecnologías utilizadas

### 🤖 [Ultralytics / YOLOv8](https://github.com/ultralytics/ultralytics)
Motor de detección de objetos. **YOLOv8** (You Only Look Once v8) es un modelo de deep learning que analiza cada frame completo en una sola pasada de red neuronal, logrando velocidad y precisión en tiempo real. Se puede elegir entre tres tamaños:
- `yolov8n` — Nano (más rápido, menos preciso)
- `yolov8s` — Small (balance)
- `yolov8m` — Medium (más preciso, más lento)

El modelo se descarga automáticamente la primera vez que se usa.

---

### 📷 [OpenCV (`opencv-python-headless`)](https://opencv.org/)
Biblioteca de visión por computadora usada para:
- Capturar frames desde la webcam o archivos de video.
- Convertir entre espacios de color (BGR ↔ RGB).
- Mostrar ventanas de video con bounding boxes.
- Guardar capturas (snapshots) como archivos de imagen.
- Detectar y abrir múltiples cámaras disponibles en el sistema (DirectShow, MSMF).

---

### 🖼️ [Pillow (`PIL`)](https://pillow.readthedocs.io/)
Librería de procesamiento de imágenes usada para:
- Redimensionar frames y adaptarlos al canvas de la interfaz gráfica.
- Convertir arrays de NumPy a formato `ImageTk` compatible con Tkinter.

---

### 🔊 [gTTS (Google Text-to-Speech)](https://gtts.readthedocs.io/)
Convierte el texto de guía generado por el sistema a audio en español usando la API de Google. Se usa el acento mexicano (`tld="com.mx"`) para mayor naturalidad. Genera archivos MP3 temporales que luego son reproducidos por pygame.

---

### 🎵 [pygame](https://www.pygame.org/)
Usado exclusivamente para la reproducción de audio MP3 generado por gTTS. Maneja la carga, reproducción y espera hasta que el audio termina (`get_busy()`).

---

### 🔢 [NumPy](https://numpy.org/)
Manejo de arrays para procesamiento de frames. Los frames de video son arrays NumPy de forma `(H, W, 3)`. También se usa para generar un frame vacío de warmup al cargar el modelo.

---

### 🖥️ [Tkinter](https://docs.python.org/3/library/tkinter.html)
Framework de interfaz gráfica estándar de Python, usado en `app_gui.py` para construir la ventana principal con:
- Sidebar de configuración con controles deslizantes, comboboxes y checkboxes.
- Canvas de visualización de video en vivo con bounding boxes.
- Panel inferior de detecciones y guía de voz en texto.
- Botones de inicio, parada, captura y salida.

---

### ⚡ [PyTorch (`torch`)](https://pytorch.org/) *(opcional)*
Detectado automáticamente para verificar si hay GPU disponible (`cuda`). Si está presente, el modelo YOLO puede ejecutarse en GPU para mayor velocidad. Si no está instalado, el sistema funciona en CPU sin problemas.

---

### 📊 [Matplotlib](https://matplotlib.org/)
Usado en el script de CLI (`deteccion_objetos.py`) para mostrar imágenes estáticas con bounding boxes anotados en una ventana emergente.

---

## 🚀 Instalación

```bash
pip install -r requirements.txt
```

> **Nota:** PyTorch para GPU debe instalarse por separado según tu sistema operativo y versión de CUDA. Visita [pytorch.org](https://pytorch.org/get-started/locally/).

---

## 📂 Estructura del proyecto

```
SafeStepAI/
├── deteccion_objetos.py   # Núcleo de detección (CLI + módulo reutilizable)
├── app_gui_2.py           # Versión alternativa de la GUI
├── requirements.txt       # Dependencias del proyecto
├── yolov8n.pt             # Modelo YOLO descargado (se genera automáticamente)
├── resumen_video.mp3      # Último audio de resumen generado
└── README.md              # Este archivo
```

---

## 🖥️ Uso — Interfaz Gráfica

```bash
python app_gui.py
```

La app abre una ventana con panel lateral de configuración y visor de video en vivo.

### Controles disponibles:
| Control | Descripción |
|--------|-------------|
| **Modo** | Cámara web / Imagen estática / Video |
| **Cámara** | Selector de cámara + escaneo automático |
| **Espejo** | Voltea horizontalmente la imagen de la webcam |
| **Confianza mínima** | Umbral de detección (5%–95%) |
| **Modelo YOLO** | Selección entre nano, small y medium |
| **Dispositivo** | Auto / CPU / GPU (si está disponible) |
| **Filtrar objetos** | Limitar detecciones a tipos específicos (ej: `persona, auto`) |
| **Narración activa** | Activa/desactiva el audio de voz |
| **Intervalo de narración** | Segundos entre cada narración (1s–15s) |
| **Resolución de inferencia** | 320 / 416 / 640 px (velocidad vs. precisión) |
| **📷 Captura** | Guarda el frame actual como PNG |

---

## ⌨️ Uso — Script CLI

### 1. Imagen estática

```bash
python deteccion_objetos.py --source foto.jpg --type image
```

### 2. Archivo de video

```bash
python deteccion_objetos.py --source video.mp4 --type video
```

### 3. Cámara web (por defecto)

```bash
python deteccion_objetos.py --type webcam
```

### Parámetros

| Parámetro | Corto | Descripción | Default |
|-----------|-------|-------------|---------|
| `--source` | `-s` | Ruta de imagen/video o índice de cámara | `None` (webcam 0) |
| `--type` | `-t` | `image` \| `video` \| `webcam` | `webcam` |
| `--output` | `-o` | `narrar` \| `mostrar` \| `ambos` | `ambos` |
| `--model` | `-m` | Modelo YOLO a usar | `yolov8n.pt` |
| `--max-frames` | `-f` | Límite de frames en video/webcam (0=todos) | `0` |

---

## 🔧 Arquitectura del módulo `deteccion_objetos.py`

El script está estructurado modularmente para facilitar la integración con una interfaz web (Flask/FastAPI):

| Función | Descripción |
|---------|-------------|
| `get_frame_generator(source, type)` | Generador unificado de frames (imagen / video / webcam) |
| `detectar_objetos(model, frame, conf)` | Ejecuta YOLO y devuelve lista de detecciones con posición y distancia |
| `guia_usuario(detecciones)` | Genera texto de guía narrativa con artículos en español |
| `reproducir_audio(texto, archivo)` | Convierte texto a MP3 y lo reproduce con pygame |
| `procesar_imagen(model, path, output)` | Pipeline completo para imágenes estáticas |
| `procesar_video(model, source, type, ...)` | Pipeline completo para video/webcam con resumen final |

---

## 📝 Notas

- El modelo `yolov8n.pt` se descarga automáticamente la primera vez.
- El audio se guarda como `output_audio.mp3` (imágenes) o `resumen_video.mp3` (video/webcam).
- En modo `webcam` o `video` con `--output mostrar`, presiona **q** en la ventana de video para salir.
- Las dependencias se instalan automáticamente si no están presentes al correr el script CLI.
- El sistema detecta GPU automáticamente; si no hay GPU disponible, usa CPU sin configuración adicional.
